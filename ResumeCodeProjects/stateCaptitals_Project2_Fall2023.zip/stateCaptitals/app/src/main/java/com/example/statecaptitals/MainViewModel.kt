package com.example.statecaptitals

import androidx.lifecycle.ViewModel
import kotlin.random.Random

class MainViewModel : ViewModel(){

    private var stateList : ArrayList<Capital> = arrayListOf()
    private lateinit var capital: Capital

    fun setCapital(rawDataArray: Array<String>) {
        var stateName: String
        var capitolName: String
        var stringArray: List<String>
        for (state in rawDataArray) {
            stringArray = state.split(",")
            stateName = stringArray[0]
            capitolName = stringArray[1]
            capital = Capital(stateName, capitolName)
            stateList.add(capital)
        }

    }
    fun  getCapital(): String {
        var capitalObject = stateList.get(Random.nextInt(stateList.size))
        var messageString = "${capitalObject.capitalCity} is the capital of  ${capitalObject.state}"
        return messageString
    }

}




