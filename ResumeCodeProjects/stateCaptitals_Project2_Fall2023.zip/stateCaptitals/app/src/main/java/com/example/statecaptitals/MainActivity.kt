package com.example.statecaptitals

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.ViewModelProvider
import com.example.statecaptitals.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)


        val rawDataArray = resources.getStringArray(R.array.states)
        viewModel.setCapital(rawDataArray)



        binding.capitalInfo.text= viewModel.getCapital()

        binding.nextButton.setOnClickListener {
            binding.capitalInfo.text= viewModel.getCapital()
        }

        }
    }
