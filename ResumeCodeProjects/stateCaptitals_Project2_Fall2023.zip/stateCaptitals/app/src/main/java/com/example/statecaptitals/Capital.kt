package com.example.statecaptitals

data class Capital(var state: String, var capitalCity : String)
